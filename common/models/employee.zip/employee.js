module.exports = function(Employee) {


};
